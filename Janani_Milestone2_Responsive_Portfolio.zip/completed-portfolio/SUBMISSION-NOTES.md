# Milestone 2 — Portfolio submission notes

## What I changed
- Replaced the starter About placeholder with a personal student introduction.
- Added a project card for **RevPulse AI – Sales & Revenue Dashboard**, with a short description.
- Styled the two required sections with a restrained navy, white and soft-purple visual theme.
- Added responsive CSS so the project card stacks on narrow screens and content remains readable.
- Kept the original starter files unchanged in `original-starter/`.

## Required checks
- [x] About text replaced with a personal introduction.
- [x] One project card added with title and description.
- [x] Responsive rules added for narrow and wide widths.
- [ ] Publish the page or share the source folder and both screenshots.

## Browser checks to complete before submission
1. Ordinary case: open `index.html` in Chrome at a desktop width (for example, 1366px). Check that both sections and the project card are readable.
2. Boundary case: open Chrome DevTools (`Ctrl + Shift + I`), enable device toolbar (`Ctrl + Shift + M`), and select a narrow width such as 320px. Check that the project card stacks and there is no horizontal scrolling.
3. Use the sample portfolio content only. Do not add passwords, tokens, contact lists or patient/financial records.

## What I learned
A responsive page needs the viewport meta tag, flexible container widths and media queries. Switching the project card to one column on small screens helps keep the content readable without horizontal scrolling.

## Before submitting
1. Open `completed-portfolio/index.html` in Chrome and complete both browser checks above.
2. Capture one desktop screenshot and one mobile screenshot.
3. Publish the page or share the completed source folder with view-only access.
4. Open the shared link in a private/incognito browser window to confirm view-only access.
5. Put the live page or companion source/demo link in the submission note if available.
